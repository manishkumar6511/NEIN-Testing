import React,{useEffect, useState,useContext} from "react";
import { Card, CardContent, Typography } from '@mui/material';
import MenuItem from '@mui/material/MenuItem';
import {Select, FormControl, InputLabel, Grid } from '@mui/material';
import {TextField } from '@mui/material';
import {Button } from '@mui/material';
import './../CSS/OperationStyles.css';
import Divider from '@mui/material/Divider';
import Autocomplete from '@mui/material/Autocomplete';
import {IconButton} from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';
import { ExpandMore, ExpandLess, Margin } from '@mui/icons-material';
import { MobileDatePicker } from '@mui/x-date-pickers/MobileDatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs'
import DisplayModal from "./../centralized_components/AutoFieldModal";
import axios from 'axios';
import { ToastProvider, useToast } from './../centralized_components/Toast';
import { useLocation } from 'react-router-dom';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';

  

function FinanceReport(){

  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
  const [mawbNo, setMawbNo] = useState(null);
  const [fields, setFields] = useState([]);
  const[financeData,setFinanceData]=useState([]);
  // useEffect(() => {
  //   const storedMawbNo = localStorage.getItem('mawbNo'); // Retrieve MAWB_NO from local storage
  //   if (storedMawbNo) {
  //     setMawbNo(storedMawbNo);
  //   }
  // }, []); // Empty dependency array means this effect runs once on mount


  // const financeData = [
  //   {
  //     invoiceNumber: '31124127',
  //     customClearanceDate: '15-06-2024',
  //     invoiceTotal: '37,125',
  //     revenue: '17,135',
  //     reimbursement: '11,423',
  //     gst: '8,567',
  //     status: 'Done'
  //   },
  //   {
  //     invoiceNumber: '31124128',
  //     customClearanceDate: '26-06-2024',
  //     invoiceTotal: '26,903',
  //     revenue: '12,417',
  //     reimbursement: '8,278',
  //     gst: '6,208',
  //     status: 'Done'
  //   },
  //   {
  //     invoiceNumber: '31124129',
  //     customClearanceDate: '11-07-2024',
  //     invoiceTotal: '29,476',
  //     revenue: '13,604',
  //     reimbursement: '9,069',
  //     gst: '6,802',
  //     status: 'Done'
  //   },
  //   {
  //     invoiceNumber: '31124133',
  //     customClearanceDate: '22-07-2024',
  //     invoiceTotal: '160,744',
  //     revenue: '74,190',
  //     reimbursement: '49,460',
  //     gst: '37,095',
  //     status: 'Done'
  //   }
  // ];
  


  const [isOpen, setIsOpen] = useState(true);
  const { showToast } = useToast();
  const toggleDetails = () => {
    setIsOpen(!isOpen);
  };

  const[selectedOperation,setSelectedOperation]=useState('');
  const[selectedSearch,setSelectedSearch]=useState('');
  const[shippingBillDate,setShippingBillDate]=useState(null);
const[MAWBDate,setMAWBDate]=useState('');
const[HAWBDate,setHAWBDate]=useState('');
  const [MAWBoptions, setMAWBOptions] = useState([]); // State to hold the options for autocomplete
  const [MAWBinputValue, setMAWBInputValue] = useState('');
  const [HAWBoptions, setHAWBOptions] = useState([]); // State to hold the options for autocomplete
  const [HAWBinputValue, setHAWBInputValue] = useState('');
  const [selectedOption, setSelectedOption] = useState(null);
  const[HAWBData,setHAWBData]=useState('');
  const [selectedHawb, setSelectedHawb] = useState('');
  const[industryOptions,setIndustryOptions]=useState('');
  const[industryData,setIndustryData]=useState('');
  const[userData,setUserData]=useState('');
 const[selectedInvoice,setSelectedInvoice]=useState('');
 const[InvoiceOptions,setInvoiceOptions]=useState([]);
  const [customClearanceDate, setCustomClearanceDate] = useState(null);
 


  const DynamicFields = {
    AirImport: [
      { label: 'MAWB No', name: 'MAWB_NO' },
      { label: 'MAWB Date', name: 'MAWB_DATE' },
      { label: 'Number of Packages', name: 'NOOF_PACKAGES' },
      { label: 'Chargeable Weight', name: 'CHARGEABLE_WEIGHT' },
      { label: 'HAWB No', name: 'HAWB_NO' },
      { label: 'HAWB Date', name: 'HAWB_DATE' },
      { label: 'Gross Weight', name: 'GROSS_WEIGHT' },
      { label: 'Shipper', name: 'SHIPPER' },
      { label: 'Consignee', name: 'CONSIGNEE' },
      { label: 'Origin', name: 'ORIGIN' },
      { label: 'Destination City', name: 'DEST_CITY' },
      { label: 'Country', name: 'COUNTRY' },
      { label: 'Country Code', name: 'COUNTRY_CODE' },
      { label: 'Region Code', name: 'REGION_CODE' },
      { label: 'Airlines', name: 'AIR_LINES' },
      { label: 'Flight No', name: 'FLIGHT_NO' },
      { label: 'Flight Date', name: 'FLIGHT_DATE' },
      { label: 'Currency', name: 'CURRENCY' },
      { label: 'City Name', name: 'CITY_NAME' },
      { label: 'Main Product', name: 'MainProduct' },
      { label: 'Industry', name: 'Industry' },
      { label: 'Shipment Type', name: 'SHIPMENT_TYPE' },
      { label: 'CAN No', name: 'CAN_NO' },
      { label: 'CAN Date', name: 'CAN_DATE' },
      { label: 'CAN Amount', name: 'CAN_AMOUNT' },
      { label: 'FC BRO', name: 'FC_BRO' },
      { label: 'FHD', name: 'FHD' },
      { label: 'DO Handed Over', name: 'DO_HANDED_OVER' },
      { label: 'DO Handover Date', name: 'DO_HANDOVER_DATE' },
      { label: 'Clearance Done By', name: 'clearanceDoneBy' },
      { label: 'CHA Name', name: 'CHA_NAME' },
      { label: 'BRO Bank Name', name: 'BRO_BANK_NAME' },
      { label: 'Break Bulk', name: 'BREAK_BULK' },
      { label: 'Remarks', name: 'REMARKS' },
    ],
    AirExport: [
      { label: 'MAWB No', name: 'MAWB_NO' },
      { label: 'MAWB Date', name: 'MAWB_DATE' },
      { label: 'MAWB Number of Packages', name: 'MAWB_NOOF_PKGS' },
      { label: 'MAWB Chargeable Weight (KG)', name: 'MAWB_CHARGEABLE_WEIGHT_KG' },
      { label: 'MAWB Total Freight Amount', name: 'MAWB_TOTAL_FREIGHT_AMOUNT' },
      { label: 'Shipment Type', name: 'SHIPMENT_TYPE' },
      { label: 'HAWB No', name: 'HAWB_NO' },
      { label: 'HAWB Date', name: 'HAWB_DATE' },
      { label: 'HAWB Total Amount', name: 'HAWB_TOTAL_AMOUNT' },
      { label: 'HAWB Gross Weight', name: 'HAWB_GROSS_WEIGHT' },
      { label: 'HAWB Chargeable Weight (KG)', name: 'HAWB_CHARGEABLE_WEIGHT_KG' },
      { label: 'HAWB Number of Packages', name: 'HAWB_NOOF_PKGS' },
      { label: 'NEWINS Reference No', name: 'NEWINS_REFERENCE_NO' },
      { label: 'Shipper', name: 'SHIPPER' },
      { label: 'Consignee', name: 'CONSIGNEE' },
      { label: 'Origin', name: 'ORIGIN' },
      { label: 'Destination', name: 'DESTINATION' },
      { label: 'Country', name: 'COUNTRY' },
      { label: 'Country Code', name: 'COUNTRY_CODE' },
      { label: 'Region Code', name: 'REGION_CODE' },
      { label: 'Airline Name', name: 'AIR_LINE_NAME' },
      { label: 'Flight No', name: 'FLIGHT_NO' },
      { label: 'Tariff Rate', name: 'TARIFF_RATE' },
      { label: 'DDU/DDP', name: 'DDU_DDP' },
      { label: 'Description of Goods', name: 'DESCRIPTION_OF_GOODS' },
      { label: 'Main Product', name: 'MainProduct' },
      { label: 'Industry', name: 'industry' },
      { label: 'Buying Rate', name: 'BUYING_RATE' },
      { label: 'Selling Rate', name: 'SELL_RATE' },
      { label: 'Margin (KG)', name: 'MARGIN_KG' },
      { label: 'Total Margin', name: 'TOTAL_MARGIN' },
      { label: 'Freight Amount', name: 'FREIGHT_AMOUNT' },
      { label: 'Due Carrier', name: 'DUE_CARRIER' },
      { label: 'Net Due', name: 'NETDUE' },
      { label: 'Shipper Invoice No', name: 'SHIPPER_INVOICE_NO' },
      { label: 'Shipping Bill No', name: 'SHIPPING_BILL_NO' },
      { label: 'Shipping Bill Date', name: 'SHIPPING_BILL_DATE' },
      { label: 'Clearance Done By', name: 'clearanceDoneBy' },
      { label: 'Customs Clearance Date', name: 'CUSTOMS_CLEARANCE_DATE' },
      { label: 'CHA', name: 'cha' },
      { label: 'Sales PIC', name: 'SalesPic' },
      { label: 'Sales PIC Branch', name: 'salesPicBranch' },
      { label: 'Operation PIC', name: 'OperationPic' },
      { label: 'IATA Agent', name: 'IATA_AGENT' },
      { label: 'Sub Agent', name: 'SUB_AGENT' },
      { label: 'Remarks', name: 'REMARKS' },
    ],
    OceanImport: [
      { label: 'MBL No', name: 'MBL_NO' },
      { label: 'MBL Date', name: 'MBL_DATE' },
      { label: 'HBL No', name: 'HBL_NO' },
      { label: 'HBL Date', name: 'HBL_DATE' },
      { label: 'Shipment Type', name: 'SHIPMENT_TYPE' },
      { label: 'Importer', name: 'IMPORTER' },
      { label: 'Shipper', name: 'SHIPPER' },
      { label: 'Manifest', name: 'MANIFEST' },
      { label: 'Currency', name: 'CURRENCY' },
      { label: 'Port of Loading', name: 'PORT_OF_LOADING' },
      { label: 'Port of Discharge', name: 'PORT_OF_DISCHARE' },
      { label: 'Place of Delivery', name: 'PLACE_OF_DELIVERY' },
      { label: 'Port Code', name: 'PORT_CODE' },
      { label: 'Number of Containers', name: 'NO_OF_CONTAINERS' },
      { label: 'Number of Packages', name: 'NOOF_PACKAGES' },
      { label: 'TEUS', name: 'TEUS' },
      { label: 'ETD', name: 'ETD' },
      { label: 'Region Code', name: 'REGION_CODE' },
      { label: 'Region Name', name: 'REGION_NAME' },
      { label: 'Country of Loading', name: 'COUNTRY_OF_LOADING' },
      { label: 'INCO Terms', name: 'INCO_TERMS' },
      { label: 'Container Type', name: 'CONTAINER_TYPE' },
      { label: 'Container No', name: 'CONTAINER_NO' },
      { label: 'Vessel No', name: 'VESSEL_NO' },
      { label: 'Main Product', name: 'MainProduct' },
      { label: 'Industry', name: 'Industry' },
      { label: 'FCL', name: 'FCL' },
      { label: 'LCL CBM', name: 'LCL_CBM' },
      { label: 'Commodity', name: 'COMMODITY' },
      { label: 'Currency', name: 'CURRENCY' },
      { label: 'ETA BLR', name: 'ETA_BLR' },
      { label: 'ETA MAA', name: 'ETA_MAA' },
      { label: 'Buying Rate Ocean Freight Local (USD)', name: 'BUYING_RATE_OCEAN_FREIGHT_LOCAL_USD' },
      { label: 'Selling Freight Rate (USD)', name: 'SELLING_FREIGHT_RATE_USD' },
      { label: 'Total Freight in INR', name: 'TOTAL_FREIGHT_IN_INR' },
      { label: 'Margin', name: 'MARGIN' },
      { label: 'Agent', name: 'AGENT' },
      { label: 'Liner Payment', name: 'LINER_PAYMENT' },
      { label: 'FCL_DES', name: 'FCL_DES' },
      { label: 'Profit Share (USD)', name: 'PROFIT_SHARE_USD' },
      { label: 'Clearance Done By', name: 'clearanceDoneBy' },
      { label: 'Cleared On', name: 'ClearedOn' },
      { label: 'CTN', name: 'CTN' },
      { label: 'Remarks', name: 'REMARKS' },
    ],
    OceanExport: [
      { label: 'MBL No', name: 'MBL_NO' },
      { label: 'MBL Date', name: 'MBL_DATE' },
      { label: 'HBL No', name: 'HBL_NO' },
      { label: 'HBL Date', name: 'HBL_DATE' },
      { label: 'Shipment Type', name: 'SHIPMENT_TYPE' },
      { label: 'Shipper', name: 'SHIPPER' },
      { label: 'Consignee', name: 'CONSIGNEE' },
      { label: 'Port of Loading', name: 'PORT_OF_LOADING' },
      { label: 'Port of Departure', name: 'PORT_OF_DEPARTURE' },
      { label: 'Place of Delivery', name: 'PLACE_OF_DELIVERY' },
      { label: 'Shipping Coloader Name', name: 'SHIPPING_COLOADER_NAME' },
      { label: 'Vessel Voyage', name: 'VESSEL_VOYAGE' },
      { label: 'ETD SOB Date', name: 'ETD_SOB_DATE' },
      { label: 'No of Container', name: 'NO_OF_CONTAINER' },
      { label: 'Volume CBM', name: 'VOLUME_CBM' },
      { label: 'Container No', name: 'CONTAINER_NO' },
      { label: 'Origin', name: 'ORIGIN' },
      { label: 'FCL', name: 'FCL' },
      { label: 'LCL CBM', name: 'LCL_CBM' },
      { label: 'Commodity', name: 'COMMODITY' },
      { label: 'No of Packages', name: 'NOOF_PACKAGES' },
      { label: 'TEUS', name: 'TEUS' },
      { label: 'Gross Weight', name: 'GROSS_WEIGHT' },
      { label: 'Currency', name: 'CURRENCY' },
      { label: 'FCL TUES', name: 'FCL_TUES' },
      { label: 'Sailing Date', name: 'SAILING_DATE' },
      { label: 'Region Code', name: 'REGION_CODE' },
      { label: 'Region Name', name: 'REGION_NAME' },
      { label: 'ETD', name: 'ETD' },
      { label: 'ETA', name: 'ETA' },
      { label: 'Main Product', name: 'MainProduct' },
      { label: 'Industry', name: 'Industry' },
      { label: 'Seal No', name: 'SEAL_NO' },
      { label: 'Buying Rate Ocean Freight Local USD', name: 'BUYING_RATE_OCEAN_FREIGHT_LOCAL_USD' },
      { label: 'Selling Freight Rate USD', name: 'SELLING_FREIGHT_RATE_USD' },
      { label: 'GST', name: 'GST' },
      { label: 'Total Freight in INR', name: 'TOTAL_FREIGHT_IN_INR' },
      { label: 'Margin', name: 'MARGIN' },
      { label: 'Shipping Bill No', name: 'SHIPPING_BILL_NO' },
      { label: 'Shipping Bill Date', name: 'SHIPPING_BILL_DATE' },
      { label: 'Sector', name: 'SECTOR' },
      { label: 'Cleared On', name: 'CLEARED_ON' },
      { label: 'Clearance Done By', name: 'clearanceDoneBy' },
      { label: 'Exporter Inv No', name: 'EXPORTER_INV_NO' },
      { label: 'VSL Voyage', name: 'VSL_VOYAGE' },
      { label: 'CHA Name', name: 'CHA_NAME' },
      { label: 'Cargo Received', name: 'CARGO_RECEIVED' },
      { label: 'Closed/Open', name: 'CLOSED_OPEN' },
      { label: 'FC Bro OK', name: 'FC_BRO_OK' },
      { label: 'ETA ICD CFS', name: 'ETA_ICD_CFS' },
      { label: 'ETA Mother Port', name: 'ETA_MOTHER_PORT' },
      { label: 'CTN', name: 'CTN' },
      { label: 'CSPIC SaleSpic', name: 'CSPIC_SALESPIC' },
      { label: 'Remarks', name: 'REMARKS' },
    ]
  };


  

const searchBy=[
  // {label:'Select',value:''},
  {label:'Invoice No',value:'Invoice'},
  {label:'HAWB No',value:'HAWB'},
]

const operations=[
  {label:'Air Import',value:'AirImport'},
  {label:'Air Export',value:'AirExport'},
  {label:'Ocean Import',value:'OceanImport'},
  {label:'Ocean Export',value:'OceanExport'},
]


const handleOperations=async(event, newValue)=>{
  setSelectedOperation(newValue.value);
  const selected=newValue.value;
  setFields(DynamicFields[selected] || []);
  setSelectedSearch('');
  
}

const handleSearch = (event, newValue) => {
  setSelectedSearch(newValue.value);
  console.log("search value", newValue.value);
  setFields(DynamicFields[selectedOperation] || []);
setFinanceData([]);
  
};

const handleFieldChange = (index, event) => {
  const newFields = [...fields];
  newFields[index].value = event.target.value;
  setFields(newFields);
};



  useEffect(() => {
    const fetchSuggestions = async () => {
      if(selectedSearch==='HAWB'){
      if (MAWBinputValue) {
        try {
          console.log("suggestions",MAWBinputValue);
          const response = await axios.post(`${API_BASE_URL}/finance/getHAWB_NO`, {
            HAWB_NO:MAWBinputValue
          });
          setMAWBOptions(response.data); // Set the fetched options
          console.log("MAWB Options",response.data);
          if(response.data.length<=0){
            console.log("MAWB No already Exists");
          }
        } catch (error) {
          console.error('Error fetching MAWB suggestions:', error);
        }
      } else {
        setMAWBOptions([]); // Clear options if input is empty
      }
    }else{
      try {
      if(selectedInvoice){
        console.log("selectedInvoice",selectedInvoice);
        const response = await axios.post(`${API_BASE_URL}/finance/getInvoice`, {
          Invoice_No:selectedInvoice, 
          Division:"1"
        });
        setInvoiceOptions(response.data); // Set the fetched options
        console.log("Invoice Options",response.data);
        if(response.data.length<=0){
          console.log("MAWB No already Exists");
        }
      }
      } catch (error) {
        console.error('Error fetching MAWB suggestions:', error);
      }

    }
    };

    const debounceFetch = setTimeout(fetchSuggestions, 300); // Debounce to limit API calls

    return () => clearTimeout(debounceFetch); // Cleanup the timeout on component unmount
  }, [MAWBinputValue,selectedInvoice]);



  

  const handleOptionChange = async (event, newValue) => {
    console.log("option change",newValue);
    if (newValue) {
      try {
        let responseData = null;
       let finance=null;
        if(selectedSearch==="HAWB"){
          console.log("if");
        const  response = await axios.post(`${API_BASE_URL}/finance/getHAWB_NOData`, {
            HAWB_NO: newValue
          });
          finance=response.data;
          responseData = response.data[0];
          console.log('Response data HAWB Data:', responseData);
          console.log("fields before",fields);
        }else{
          console.log("else");
         const response1 = await axios.post(`${API_BASE_URL}/finance/getHAWB_NODataFromInvoice`, {
            Invoice_No: newValue
          });

          responseData = response1.data[0];
          console.log('Response data Invoice Data:', response1.data);
          finance=response1.data;
        }
        const updatedFields = fields.map(field => ({
          ...field,
          value: responseData[field.name] || ''
          
        }));
        console.log("fields After",updatedFields);
        setFields(updatedFields);
       
        setFinanceData(finance);
       
      }
        catch (error) {
          if (axios.isAxiosError(error)) {
              // Handle Axios error specifically
              console.error('Error fetching MAWB details:', error.message);
              if (error.response) {
                  showToast(`Error: ${error.response.data}`, "error");
              } else {
                  // The request was made but no response was received
                  console.error('Error request:', error.request);
                  showToast('No response received from server', "error");
              }
          } else {
              // Handle non-Axios errors
              console.error('Unexpected error:', error);
              showToast('An unexpected error occurred', "error");
          }
        }
      
    }else{
      setHAWBOptions([]);
    }
  };


  const handleHawbChange = (event, newValue, optionDetails) => {
    setSelectedHawb(newValue);
    const selectedOptionDetails = Array.isArray(optionDetails)?optionDetails : selectedOption;
    if (newValue) {
      if (selectedOptionDetails) {
        const selectedHAWBDetails = selectedOptionDetails.find(item => item.MASTER_HOUSE_BL === newValue);
        if (selectedHAWBDetails) {
          console.log('Selected HAWB Details:', selectedHAWBDetails);
          setHAWBData(selectedHAWBDetails);
          updateAutoFields(selectedHAWBDetails);
        } else {
          console.error('Selected HAWB not found in selectedOption:', newValue);
        }
      } else {
        console.error('selectedOption is not defined');
      }
    }
  };


  const updateAutoFields = (hawbData) => {
    // setAutoFields({
    //   MAWB_NO: hawbData.MAWB_BL_NO || '',
    //   MAWB_DATE: hawbData.BL_CONSO_DATE ? dayjs(hawbData.BL_CONSO_DATE, 'DD-MM-YY') : null,// Default to current date if not set
    //   MAWB_NOOF_PKGS: hawbData.TOTAL_NO_OF_PKGS || '',
    //   MAWB_CHARGEABLE_WEIGHT_KG: hawbData.TOTAL_CHARGEABLE_WGT || '',
    //   MAWB_TOTAL_FREIGHT_AMOUNT:(hawbData&&hawbData.FREIGHT_PC_SIGN==='C')?(hawbData&&hawbData.CHARGE_TOTAL_CC):(hawbData&&hawbData.CHARGE_TOTAL_PP),
    //   SHIPMENT_TYPE:(hawbData&&hawbData.FREIGHT_PC_SIGN==='P')?'PP':'CC' || '',
	  //   HAWB_NO: hawbData.MASTER_HOUSE_BL || '',
    //   HAWB_DATE:(hawbData.MASTER_HOUSE_BL && hawbData.BL_CONSO_DATE) ? dayjs(hawbData.BL_CONSO_DATE, 'DD-MM-YY') : null,
    //   HAWB_TOTAL_AMOUNT:(hawbData.MASTER_HOUSE_BL)? hawbData.CHARGE_TOTAL_CC : '',
    //   HAWB_GROSS_WEIGHT: (hawbData.MASTER_HOUSE_BL)?hawbData.TOTAL_ACTUAL_WEIGHT : '',
    //   HAWB_CHARGEABLE_WEIGHT_KG: (hawbData.MASTER_HOUSE_BL)?hawbData.TOTAL_CHARGEABLE_WGT : '',
    //   HAWB_NOOF_PKGS:(hawbData.MASTER_HOUSE_BL)? hawbData.TOTAL_NO_OF_PKGS : '',
    //   NEWINS_REFERENCE_NO: hawbData.REF_NO_BR_DV_OR_REF_NO_SEQ || '',
    //   SHIPPER: hawbData.SHIPPER_NAME || '',
    //   CONSIGNEE: hawbData.CONSIGNEE_NAME || '',
    //   ORIGIN: hawbData.DEPARTURE_CITY || '',
    //   DESTINATION: hawbData.DESTINATION_CITY || '',
    //   COUNTRY: hawbData.CTCTNM || '',
    //   COUNTRY_CODE: hawbData.CTISO || '',
    //   REGION_CODE: hawbData.IATACODE || '',
    //   AIR_LINE_NAME: hawbData.FLIGHT_CARRIER_CODE || '',
    //   FLIGHT_NO: hawbData.FLIGHT_NO1 || '',
    //   TARIFF_RATE: hawbData.TARIFF_RATE || '',
    //   DDU_DDP: ((hawbData&&hawbData.FREE_HOUSE_SIGN==='I')?'DDP':'Select')||((hawbData&&hawbData.FREE_HOUSE_SIGN==='E')?'DDU':'Select'),
    //   DESCRIPTION_OF_GOODS: hawbData.DESCRIPTION_OF_GOODS || '',
    // });
  };



  const handleInputChange = (e) => {
    setMAWBInputValue(e.target.value); // Update the input value
  };



  

  const handleCustomDate=(newDate)=>{
    setCustomClearanceDate(newDate.format('DD/MM/YYYY'));
  
  }















return(
    <div>
        <Card className="main-card" >

<p className='card-title'>Freight Forwarding </p>

<CardContent>
  <Typography variant="h5" component="div">
    </Typography>
    <Grid container spacing={2}>
<Grid item xs={4}>
<Autocomplete size='small'  freeSolo id="free-solo-2-demo" disableClearable 
      options={operations}
      onChange={handleOperations}
    style={{padding:'0px'}}
      value={selectedOperation || null} 
       renderInput={(params) => (
       <TextField 
        {...params}
        label="Operation Type"
        InputProps={{
        ...params.InputProps,
        type: 'search',
        }}
        InputLabelProps={{ style: { fontSize: '14px'} }}
        required
         
        />)}/> 
      
</Grid>
<Grid item xs={4}>
<Autocomplete size='small'  freeSolo id="free-solo-2-demo" disableClearable 
      options={searchBy}
      onChange={handleSearch}
      style={{padding:'0px'}}
      value={searchBy.label  || null} 
       renderInput={(params) => (
       <TextField 
        {...params}
        label="Search By"
        InputProps={{
        ...params.InputProps,
        type: 'search',
        }}
        InputLabelProps={{ style: { fontSize: '14px'} }}
        required
         
        />)}/> 
      
</Grid>


{selectedSearch==='HAWB' && (
    <Grid item xs={4}>
        <FormControl fullWidth>
        <Autocomplete size='small'  freeSolo id="free-solo-2-demo" disableClearable 
       options={MAWBoptions.map(option => option.HAWB_NO)}
       onInputChange={(event, newInputValue) => {
        setMAWBInputValue(newInputValue); // Update input value
       
      }} 
      style={{padding:'0px'}}
      value={mawbNo || ''}
      onChange={handleOptionChange}
      onKeyDown={(event) => {
        if (event.key === 'Tab') {
            // Get the current input value
            const currentValue = MAWBinputValue;

            // Call the onChange function manually
            handleOptionChange(event, currentValue); // Call onChange with the current input value
            
            // Optional: You can also prevent the default behavior if needed
            // event.preventDefault();
        }
      }}
       renderInput={(params) => (
       <TextField 
        {...params}
        label="HAWB No"
        InputProps={{
        ...params.InputProps,
        type: 'search',
        }}
        InputLabelProps={{ style: { fontSize: '14px'} }}
        required
         className="custom-textfield"
        />)}/> 
          </FormControl>
        </Grid>
)}
        {selectedSearch==='Invoice' && (
        <Grid item xs={4}>
        <FormControl fullWidth>
        <Autocomplete size='small'  freeSolo id="free-solo-2-demo" disableClearable 
      options={InvoiceOptions.map(option => option.InvoiceNo)}
      onChange={handleOptionChange}
    
      onInputChange={(event, newInputValue) => {
        setSelectedInvoice(newInputValue); // Update input value
       
      }} 
      style={{padding:'0px'}}
       renderInput={(params) => (
       <TextField 
        {...params}
        label="Invoice No"
        InputProps={{
        ...params.InputProps,
        type: 'search',
        }}
        InputLabelProps={{ style: { fontSize: '14px'} }}
        required
         className="custom-textfield"
        />)}/> 
        </FormControl>
        </Grid>
        )}
  </Grid>
    </CardContent>
      
    </Card>
    {selectedOperation &&(
    <Card className="finance-card">

  <p className='finance-card-name'>Operational Fields </p>
 


<Divider className="divider"/>

     
<CardContent>
<Typography variant="h5" component="div">
   <Grid container spacing={2} style={{marginTop:'8px'}}>
   {fields.map((field, index) => (
         
          
         <Grid item xs={2}>
         <FormControl fullWidth>
       <TextField
         key={index}
         label={field.label}
         name={field.name}
         value={field.value || ''}
         variant="outlined"
         InputProps={{
           readOnly: true,
         }}
         size='small'
         style={{ marginBottom: '3px' }}
         onChange={(e) => handleFieldChange(index, e)}
         className='disabled-textfield'
         InputLabelProps={{ style: { fontSize: '14px' ,shrink:'true' } }}
       />
       </FormControl>
       </Grid>
      
      
     ))}
    </Grid>
    </Typography>
    </CardContent>
      
    </Card>
      
    )}

{selectedOperation&&(
<Card className="card-remaining">
<p className='finance-card-remaining'>Finance Data </p>
<Divider className="divider"/>
<CardContent>
<Typography variant="h5" component="div">
{financeData.map((data, index) => {
      //  const invoiceTotal = parseFloat(data.invoiceTotal.replace(/,/g, ''));
      //  const revenue = parseFloat(data.revenue.replace(/,/g, ''));
      //  const reimbursement = parseFloat(data.reimbursement.replace(/,/g, ''));
      //  const gst = parseFloat(data.gst.replace(/,/g, ''));
       
      //  const total = revenue + reimbursement + gst;
       
      //  // Check if the absolute difference is within 10 rupees
      //  const isMatching = Math.abs(invoiceTotal - total) <= 10;

        return (
          <Grid container spacing={2} key={index} style={{marginTop:'0px'}}>
            <Grid item xs={1.9}>
              <TextField
                value={data.InvoiceNo ||null}
                className="disabled-textfield"
                name="invoiceNumber"
                label="Invoice Number"
                
                InputProps={{
                  readOnly: true,
                }}
                size="small"
                InputLabelProps={{ style: { fontSize: '14px', shrink: 'true' } }}
              />
            </Grid>
            <Grid item xs={1.9}>
             <TextField
                value={data.IssueDate || null}
                className="disabled-textfield"
                name="customClearanceDate"
                label="Invoice Date"
                
                InputProps={{
                  readOnly: true,
                }}
                size="small"
                InputLabelProps={{ style: { fontSize: '14px', shrink: 'true' } }}
              />
            </Grid>
            <Grid item xs={1.9}>
              <TextField
                value={data.Amount || null}
                className="disabled-textfield"
                name="invoiceTotal"
                label="Invoice Total"
               
                InputProps={{
                  readOnly: true,
                }}
                size="small"
                InputLabelProps={{ style: { fontSize: '14px', shrink: 'true' } }}
              />
            </Grid>
            <Grid item xs={1.9}>
              <TextField
                value={data.Revenue || null}
                className="disabled-textfield"
                name="revenue"
                label="Revenue"
              
                InputProps={{
                  readOnly: true,
                }}
                size="small"
                InputLabelProps={{ style: { fontSize: '14px', shrink: 'true' } }}
              />
            </Grid>
            <Grid item xs={1.9}>
              <TextField
                value={data.Reimbursement || null}
                className="disabled-textfield"
                name="reimbursement"
                label="Reimbursement"
               
                InputProps={{
                  readOnly: true,
                }}
                size="small"
                InputLabelProps={{ style: { fontSize: '14px', shrink: 'true' } }}
              />
            </Grid>
            <Grid item xs={1.9}>
              <TextField
                value={data.GST || null}
                className="disabled-textfield"
                name="gst"
                label="GST"
               
                InputProps={{
                  readOnly: true,
                }}
                size="small"
                InputLabelProps={{ style: { fontSize: '14px', shrink: 'true' } }}
              />
            </Grid>
            <Grid item xs={0.6}>
              {data.Status ? (
                <CheckIcon style={{ color: 'green' }} />
              ) : (
                <CloseIcon style={{ color: 'red' }} />
              )}
            </Grid>
          </Grid>
        );
      })}



</Typography>
</CardContent>
</Card>
)}


        
           
           
            
           
              {/* <Button  variant="contained" className="AirButton" style={{marginRight:'10px'}} onClick={handleSubmit} >Submit</Button>
           
              <Button variant="contained" className="AirButton" >Reset</Button> */}
           
          
   
   
    </div>
)

}
export default FinanceReport;