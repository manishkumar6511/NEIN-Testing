import React from 'react'

const Home = () => {
  return (
    <>
      <h1> Welcome home </h1>
    </>
  )
}

export default Home
