const API_BASE_URL = 'http://localhost:9090'; // Your base API URL
const fileURL= 'http://localhost:3000/';
export const API_ENDPOINTS = {
    FETCH_DATA: `${API_BASE_URL}/`,
    file_Url:'{fileURL}/',
    // Add more endpoints as needed
};